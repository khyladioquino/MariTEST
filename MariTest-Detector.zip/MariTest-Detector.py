import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk


class MyGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("MariTEST Detector")
        self.root.geometry("800x600")

        bg = ImageTk.PhotoImage(file="Photos/bgd.png")

        label_bg = tk.Label(self.root, image=bg)
        label_bg.place(x=0, y=0, relwidth=1, relheight=1)

        photo = Image.open("Photos/3.png")
        resize_pic = photo.resize((250, 250), Image.ANTIALIAS)
        convert_pic = ImageTk.PhotoImage(resize_pic)

        self.label = tk.Label(self.root, image=convert_pic, width=300, height=300, bg='black')
        self.label.pack(padx=5, pady=5)

        self.label = tk.Label(self.root, text="Enter News:", font=('Times New Roman', 16), bg="black", fg="white")
        self.label.pack(padx=5, pady=5)

        self.textbox = tk.Text(self.root, height=4, font=('Arial', 12))
        self.textbox.pack(padx=10, pady=10)

        self.clrButton = tk.Button(self.root, text="Clear", font=('Times New Roman', 12), bg="white",
                                   command=self.clear)
        self.clrButton.place(x=420, y=480)

        self.button = tk.Button(self.root, text="Enter", font=('Times New Roman', 12), bg="white", command=self.detect)
        self.button.place(x=320, y=480)

        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.root.mainloop()

    def detect(self):
        import re
        import string
        from newspaper import Article
        import nltk

        try:
            from googlesearch import search
        except ImportError:
            print("No module named 'google' found")

        def calculate_jaccard(word_tokens1, word_tokens2):
            # Combine both tokens to find union.
            both_tokens = word_tokens1 + word_tokens2
            union = set(both_tokens)

            # Calculate intersection.
            intersection = set()
            for w in word_tokens1:
                if w in word_tokens2:
                    intersection.add(w)

            jaccard_score = len(intersection) / len(union)
            return int(jaccard_score * 100)

        def linkToArticle(x):
            try:
                article = Article(x)
                article.download()
                article.parse()
                article.nlp()
            except UnknownTimezoneWarning as e:
                print("ERROR")

            return article.summary

        def detector(query):
            for i in search(query, tld="co.in", num=10, stop=10, pause=2):

                url_pattern1 = 'https://(.+?)\\.gmanetwork\\.com/(.+?)/'
                url_pattern2 = 'https://mb\\.com\\.ph/(.+?)/'
                url_pattern3 = 'https://(.+?)\\.inquirer\\.net/(.+?)/'
                url_pattern4 = 'https://www\\.philstar\\.com/(.+?)/'
                url_pattern5 = 'https://news\\.abs-cbn\\.com/(.+?)/'

                if re.match(url_pattern1, i):
                    arrLink = ['GMA Network', linkToArticle(i), i]
                    arrArticle.append(arrLink)

                elif re.match(url_pattern2, i):
                    arrLink = ['Manila Bulletin', linkToArticle(i), i]
                    arrArticle.append(arrLink)

                elif re.match(url_pattern3, i):
                    arrLink = ['Philippine Daily Inquirer', linkToArticle(i), i]
                    arrArticle.append(arrLink)

                elif re.match(url_pattern4, i):
                    arrLink = ['The Philippine Star', linkToArticle(i), i]
                    arrArticle.append(arrLink)

                elif re.match(url_pattern5, i):
                    arrLink = ['abs-cbn', linkToArticle(i), i]
                    arrArticle.append(arrLink)

        query = self.textbox.get('1.0', tk.END)

        arrArticle = []
        arrLink = []

        if re.match('https://(.+?)', query):
            a = linkToArticle(query)

            detector(a)

        else:
            a = query
            detector(a)

        print('')
        if len(arrArticle) == 0:
            # print('Beware, it is a Fake News.')
            messagebox.showinfo(title="Result", message='Beware, it is a Fake News.')

        else:
            for i in range(0, len(arrArticle)):
                if calculate_jaccard(a, arrArticle[i][1]) == 100:
                    # print('It is 100% true according to', arrArticle[i][0] + '. For more info visit: ', arrArticle[i][2])
                    messagebox.showinfo(title="Result", message='It is 100% true according to ' + arrArticle[i][
                        0] + '. For more info visit: ' + arrArticle[i][2])
                    break

                else:
                    # print('According to', arrArticle[i][0] + ', it is', str(calculate_jaccard(a, arrArticle[i][1])) +
                    #       '% true. For more info visit: ', arrArticle[i][2], '\n')
                    messagebox.showinfo(title="Result", message='According to ' + arrArticle[i][0] + ', it is ' + str(
                        calculate_jaccard(a, arrArticle[i][1])) + '% true. For more info visit: ' + arrArticle[i][
                                                                    2] + '\n')

    def clear(self):
        self.textbox.delete('1.0', tk.END)

    def close(self):
        if messagebox.askyesno(title="Quit", message="Do you really want to quit?"):
            self.root.destroy()


MyGUI()
